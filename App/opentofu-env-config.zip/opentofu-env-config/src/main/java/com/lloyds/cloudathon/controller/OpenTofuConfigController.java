package com.lloyds.cloudathon.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class OpenTofuConfigController {

    @Value("${env}")
    private String env;

    @Value("${host}")
    private String host;

    @GetMapping("/opentofu/config")
    public String getConfig(Model model) {
        model.addAttribute("env", env);
        model.addAttribute("host", host);
        return "opentofu-env";
    }

}
