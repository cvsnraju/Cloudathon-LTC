package com.lloyds.cloudathon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpentofuEnvConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
